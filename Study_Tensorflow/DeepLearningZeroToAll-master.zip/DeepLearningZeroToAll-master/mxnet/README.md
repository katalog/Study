# [WIP] Lab code using MXNet
All the codes in the repo are tested using the MXNet with commit id [f89f9654](https://github.com/dmlc/mxnet/commit/f89f96540ec477de6f2e0fee5001df0b78810316).
